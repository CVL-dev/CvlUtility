Link to CSIRO imaging project
