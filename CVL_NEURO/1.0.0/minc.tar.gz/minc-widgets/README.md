minc-widgets
============

Collection of MINC widgets, generally perl and shell scripts

