#!/bin/sh

message=$(cat emap_access_info.txt)

/usr/local/bin/software_management.sh "${message}"
