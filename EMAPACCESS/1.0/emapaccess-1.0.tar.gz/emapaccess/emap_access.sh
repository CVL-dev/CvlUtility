#!/bin/sh

module load emapaccess
APP="emap_access.sh"
DIR=$(which ${APP} | sed "s/\/${APP}//g")
condition_file="${DIR}/emap_access_info.txt"
message_file="${DIR}/emap_message.txt"

module load cvl
cvl_software_access.sh "${condition_file}" "${message_file}"
