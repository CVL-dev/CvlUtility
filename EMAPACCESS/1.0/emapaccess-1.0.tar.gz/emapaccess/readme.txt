For EMAP software access information
